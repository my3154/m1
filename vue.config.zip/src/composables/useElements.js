import { ref, computed } from 'vue'
import { getAbsolutePosition } from '../utils/position'

export function useElements() {
  // 元素数据 - 使用 Map 提高性能
  const elementsMap = ref(new Map())
  
  // 当前选中元素
  const selectedElementId = ref(null)
  const selectedElement = computed(() => {
    if (!selectedElementId.value) return null
    return elementsMap.value.get(selectedElementId.value)
  })
  
  // 添加新元素到画布
  const addNewElement = () => {
    const id = Date.now().toString()
    const newElement = {
      id,
      x: 100,
      y: 100,
      width: 100,
      height: 100,
      color: '#' + Math.floor(Math.random() * 16777215).toString(16),
      rotation: 0,
      parentId: null
    }
    
    elementsMap.value.set(id, newElement)
    selectedElementId.value = id
    
    return newElement
  }
  
  // 更新元素
  const updateElement = (updatedElement) => {
    if (!updatedElement || !updatedElement.id) return
    elementsMap.value.set(updatedElement.id, { ...updatedElement })
  }
  
  // 删除选中元素
  const removeSelectedElement = () => {
    if (!selectedElementId.value) return
    
    // 查找以该元素为父元素的所有子元素
    const childElements = findChildElements(selectedElementId.value)
    
    // 递归删除子元素
    const removeElementWithChildren = (elementId) => {
      // 先递归处理子元素
      const children = childElements.filter(el => el.parentId === elementId)
      children.forEach(child => removeElementWithChildren(child.id))
      
      // 然后删除当前元素
      elementsMap.value.delete(elementId)
    }
    
    removeElementWithChildren(selectedElementId.value)
    selectedElementId.value = null
  }
  
  // 查找以指定元素为父元素的所有子元素
  const findChildElements = (parentId) => {
    return Array.from(elementsMap.value.values())
      .filter(el => el.parentId === parentId)
  }
  
  // 查找指定位置处的目标元素（排除自身及其子元素）
  const findTargetElementAtPosition = (x, y, width, height, excludeId) => {
    // 获取所有元素并按照合适的顺序排序
    const elements = Array.from(elementsMap.value.values())
      .filter(el => el.id !== excludeId && !isChildOf(el.id, excludeId))
    
    // 从后向前检查（模拟 z-index）
    for (let i = elements.length - 1; i >= 0; i--) {
      const el = elements[i]
      // 检查是否在目标元素内
      if (isPositionInElement(x, y, width, height, el)) {
        return el
      }
    }
    
    return null
  }
  
  // 检查 childId 是否是 parentId 的子元素（直接或间接）
  const isChildOf = (childId, parentId) => {
    const child = elementsMap.value.get(childId)
    if (!child) return false
    if (child.parentId === parentId) return true
    if (child.parentId) return isChildOf(child.parentId, parentId)
    return false
  }
  
  // 检查位置是否在元素内
  const isPositionInElement = (x, y, width, height, element) => {
    // 获取元素的绝对位置
    const absolutePos = getAbsolutePosition(element, elementsMap.value)
    
    // 计算元素边界
    const elementRight = absolutePos.x + element.width
    const elementBottom = absolutePos.y + element.height
    
    // 计算输入区域的边界
    const regionRight = x + width
    const regionBottom = y + height
    
    return (
      x >= absolutePos.x && 
      regionRight <= elementRight && 
      y >= absolutePos.y && 
      regionBottom <= elementBottom
    )
  }
  
  return {
    elementsMap,
    selectedElementId,
    selectedElement,
    addNewElement,
    updateElement,
    removeSelectedElement,
    findTargetElementAtPosition,
    isChildOf
  }
}