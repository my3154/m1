import { ref } from 'vue'

export function useHistory(elementsMap) {
  // 历史记录
  const history = ref([])
  const historyIndex = ref(-1)
  
  // 添加历史快照
  const addHistorySnapshot = () => {
    // 创建当前状态的深拷贝
    const snapshot = new Map(
      Array.from(elementsMap.value.entries()).map(([key, value]) => [key, { ...value }])
    )
    
    // 如果当前索引不在历史结尾，则清除后面的历史
    if (historyIndex.value < history.value.length - 1) {
      history.value = history.value.slice(0, historyIndex.value + 1)
    }
    
    // 添加新快照
    history.value.push(snapshot)
    historyIndex.value = history.value.length - 1
  }
  
  // 撤销操作
  const undo = () => {
    if (historyIndex.value <= 0) return
    
    historyIndex.value--
    applySnapshot(history.value[historyIndex.value])
  }
  
  // 重做操作
  const redo = () => {
    if (historyIndex.value >= history.value.length - 1) return
    
    historyIndex.value++
    applySnapshot(history.value[historyIndex.value])
  }
  
  // 应用快照
  const applySnapshot = (snapshot) => {
    // 清除当前状态
    elementsMap.value.clear()
    
    // 应用快照
    snapshot.forEach((value, key) => {
      elementsMap.value.set(key, { ...value })
    })
  }
  
  return {
    addHistorySnapshot,
    undo,
    redo
  }
}