import { ref } from 'vue'
import { applySnapping } from './useSnapping'

export function useDrag(elementsMap, findTargetElementAtPosition, isChildOf, updateCallback) {
  // 拖拽状态
  const dragState = ref({
    isDragging: false,
    element: null,
    startX: 0,
    startY: 0,
    originalX: 0,
    originalY: 0,
    ctrlPressed: false
  })
  
  // 处理元素鼠标按下
  const handleElementMouseDown = (event, element) => {
    // 阻止事件冒泡
    event.stopPropagation()
    
    // 初始化拖拽状态
    dragState.value = {
      isDragging: true,
      element,
      startX: event.clientX,
      startY: event.clientY,
      originalX: element.x,
      originalY: element.y,
      ctrlPressed: event.ctrlKey
    }
  }
  
  // 处理拖拽移动
  const handleDragMove = (event) => {
    if (!dragState.value.isDragging) return
    
    const dx = event.clientX - dragState.value.startX
    const dy = event.clientY - dragState.value.startY
    
    const element = dragState.value.element
    const newX = dragState.value.originalX + dx
    const newY = dragState.value.originalY + dy
    
    // 更新元素位置
    updateElementPosition(element, newX, newY, dragState.value.ctrlPressed || event.ctrlKey)
  }
  
  // 处理拖拽结束
  const handleDragEnd = () => {
    dragState.value.isDragging = false
  }
  
  // 更新元素位置，处理嵌套逻辑
  const updateElementPosition = (element, newX, newY, isCtrlPressed) => {
    // 获取当前父元素
    const parentElement = element.parentId ? elementsMap.value.get(element.parentId) : null
    
    // 如果按住Ctrl键，考虑从父元素中移出
    if (isCtrlPressed && parentElement) {
      // 计算绝对位置（父元素的位置 + 当前元素的相对位置）
      let absoluteX = newX
      let absoluteY = newY
      let currentParent = parentElement
      
      while (currentParent) {
        absoluteX += currentParent.x
        absoluteY += currentParent.y
        currentParent = currentParent.parentId ? elementsMap.value.get(currentParent.parentId) : null
      }
      
      // 更新元素 - 移出父元素
      const updatedElement = {
        ...element,
        x: absoluteX,
        y: absoluteY,
        parentId: null
      }
      
      // 使用回调更新元素
      updateCallback(updatedElement)
      return
    }
    
    // 检查是否在父元素内移动
    if (parentElement) {
      // 确保在父元素边界内
      const maxX = parentElement.width - element.width
      const maxY = parentElement.height - element.height
      
      // 应用吸附效果
      const snappedPosition = applySnapping({
        x: Math.max(0, Math.min(maxX, newX)),
        y: Math.max(0, Math.min(maxY, newY))
      }, parentElement)
      
      // 更新元素
      const updatedElement = {
        ...element,
        x: snappedPosition.x,
        y: snappedPosition.y
      }
      
      // 使用回调更新元素
      updateCallback(updatedElement)
      return
    }
    
    // 如果没有父元素，检查是否移入其他元素
    const targetElement = findTargetElementAtPosition(newX, newY, element.width, element.height, element.id)
    
    if (targetElement) {
      // 计算相对于目标元素的位置
      const relativeX = newX - targetElement.x
      const relativeY = newY - targetElement.y
      
      // 设置新的父元素
      const updatedElement = {
        ...element,
        x: relativeX,
        y: relativeY,
        parentId: targetElement.id
      }
      
      // 使用回调更新元素
      updateCallback(updatedElement)
    } else {
      // 普通移动
      // 应用吸附效果
      const snappedPosition = applySnapping({ x: newX, y: newY })
      
      const updatedElement = {
        ...element,
        x: snappedPosition.x,
        y: snappedPosition.y
      }
      
      // 使用回调更新元素
      updateCallback(updatedElement)
    }
  }
  
  return {
    dragState,
    handleElementMouseDown,
    handleDragMove,
    handleDragEnd
  }
}