import { ref } from 'vue'

export function useResize(updateCallback) {
  // 调整大小状态
  const resizeState = ref({
    isResizing: false,
    element: null,
    handle: null,
    startX: 0,
    startY: 0,
    originalWidth: 0,
    originalHeight: 0,
    originalX: 0,
    originalY: 0
  })
  
  // 处理调整大小开始
  const handleResizeStart = (event, element, handle) => {
    event.stopPropagation()
    
    resizeState.value = {
      isResizing: true,
      element: { ...element },
      handle,
      startX: event.clientX,
      startY: event.clientY,
      originalWidth: element.width,
      originalHeight: element.height,
      originalX: element.x,
      originalY: element.y
    }
  }
  
  // 处理调整大小
  const handleResizeMove = (event) => {
    if (!resizeState.value.isResizing) return
    
    const dx = event.clientX - resizeState.value.startX
    const dy = event.clientY - resizeState.value.startY
    
    const state = resizeState.value
    let newWidth = state.originalWidth
    let newHeight = state.originalHeight
    let newX = state.originalX
    let newY = state.originalY
    
    // 根据不同的调整柄处理大小和位置
    switch (state.handle) {
      case 'br': // 右下
        newWidth = Math.max(20, state.originalWidth + dx)
        newHeight = Math.max(20, state.originalHeight + dy)
        break
        
      case 'bl': // 左下
        newWidth = Math.max(20, state.originalWidth - dx)
        newHeight = Math.max(20, state.originalHeight + dy)
        newX = state.originalX + (state.originalWidth - newWidth)
        break
        
      case 'tr': // 右上
        newWidth = Math.max(20, state.originalWidth + dx)
        newHeight = Math.max(20, state.originalHeight - dy)
        newY = state.originalY + (state.originalHeight - newHeight)
        break
        
      case 'tl': // 左上
        newWidth = Math.max(20, state.originalWidth - dx)
        newHeight = Math.max(20, state.originalHeight - dy)
        newX = state.originalX + (state.originalWidth - newWidth)
        newY = state.originalY + (state.originalHeight - newHeight)
        break
    }
    
    // 更新元素
    const updatedElement = {
      ...state.element,
      width: newWidth,
      height: newHeight,
      x: newX,
      y: newY
    }
    
    // 调用外部回调更新元素
    updateCallback(updatedElement)
  }
  
  // 处理调整大小结束
  const handleResizeEnd = () => {
    resizeState.value.isResizing = false
  }
  
  return {
    resizeState,
    handleResizeStart,
    handleResizeMove,
    handleResizeEnd
  }
}