import { ref } from 'vue'

export function useRotate(updateCallback) {
  // 旋转状态
  const rotateState = ref({
    isRotating: false,
    element: null,
    startAngle: 0,
    centerX: 0,
    centerY: 0,
    originalRotation: 0
  })
  
  // 处理旋转开始
  const handleRotateStart = (event, element) => {
    event.stopPropagation()
    
    // 计算元素中心点（相对于屏幕）
    const elementRect = document.getElementById('element-' + element.id).getBoundingClientRect()
    const centerX = elementRect.left + elementRect.width / 2
    const centerY = elementRect.top + elementRect.height / 2
    
    // 计算初始角度
    const startAngle = Math.atan2(
      event.clientY - centerY,
      event.clientX - centerX
    ) * (180 / Math.PI)
    
    rotateState.value = {
      isRotating: true,
      element: { ...element },
      startAngle,
      centerX,
      centerY,
      originalRotation: element.rotation
    }
  }
  
  // 处理旋转
  const handleRotateMove = (event) => {
    if (!rotateState.value.isRotating) return
    
    const state = rotateState.value
    
    // 计算当前角度
    const currentAngle = Math.atan2(
      event.clientY - state.centerY,
      event.clientX - state.centerX
    ) * (180 / Math.PI)
    
    // 计算角度差
    let angleDiff = currentAngle - state.startAngle
    
    // 规范化角度到 0-360 度
    let newRotation = (state.originalRotation + angleDiff) % 360
    if (newRotation < 0) newRotation += 360
    
    // 更新元素
    const updatedElement = {
      ...state.element,
      rotation: newRotation
    }
    
    // 调用外部回调更新元素
    updateCallback(updatedElement)
  }
  
  // 处理旋转结束
  const handleRotateEnd = () => {
    rotateState.value.isRotating = false
  }
  
  return {
    rotateState,
    handleRotateStart,
    handleRotateMove,
    handleRotateEnd
  }
}