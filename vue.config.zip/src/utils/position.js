/**
 * 位置计算工具函数
 */

/**
 * 计算元素的绝对位置（考虑嵌套）
 * @param {Object} element 元素对象
 * @param {Map} elementsMap 元素Map集合
 * @returns {Object} 绝对位置 {x, y}
 */
export function getAbsolutePosition(element, elementsMap) {
  let x = element.x || 0
  let y = element.y || 0
  let currentParentId = element.parentId
  
  // 向上遍历所有父元素，累加位置
  while (currentParentId) {
    const parentElement = elementsMap.get(currentParentId)
    if (!parentElement) break
    
    x += parentElement.x || 0
    y += parentElement.y || 0
    currentParentId = parentElement.parentId
  }
  
  return { x, y }
}

/**
 * 计算元素的相对位置
 * @param {Object} absolutePosition 绝对位置 {x, y}
 * @param {Object} parentElement 父元素
 * @param {Map} elementsMap 元素Map集合
 * @returns {Object} 相对位置 {x, y}
 */
export function getRelativePosition(absolutePosition, parentElement, elementsMap) {
  // 如果没有父元素，则相对位置就是绝对位置
  if (!parentElement) {
    return { x: absolutePosition.x, y: absolutePosition.y }
  }
  
  // 计算父元素的绝对位置
  const parentAbsolutePosition = getAbsolutePosition(parentElement, elementsMap)
  
  // 计算相对位置
  return {
    x: absolutePosition.x - parentAbsolutePosition.x,
    y: absolutePosition.y - parentAbsolutePosition.y
  }
}

/**
 * 检查一个元素是否在另一个元素内
 * @param {Object} element 要检查的元素
 * @param {Object} containerElement 容器元素
 * @param {Map} elementsMap 元素Map集合
 * @returns {Boolean} 如果元素在容器内，则返回 true
 */
export function isElementInside(element, containerElement, elementsMap) {
  // 计算两个元素的绝对位置
  const elementPos = getAbsolutePosition(element, elementsMap)
  const containerPos = getAbsolutePosition(containerElement, elementsMap)
  
  // 计算元素的边界
  const elementRight = elementPos.x + element.width
  const elementBottom = elementPos.y + element.height
  
  // 计算容器的边界
  const containerRight = containerPos.x + containerElement.width
  const containerBottom = containerPos.y + containerElement.height
  
  // 检查元素是否完全在容器内
  return (
    elementPos.x >= containerPos.x &&
    elementPos.y >= containerPos.y &&
    elementRight <= containerRight &&
    elementBottom <= containerBottom
  )
}

/**
 * 将全局坐标转换为相对于元素的本地坐标
 * @param {Number} globalX 全局X坐标
 * @param {Number} globalY 全局Y坐标
 * @param {Object} element 元素
 * @param {Map} elementsMap 元素Map集合
 * @returns {Object} 本地坐标 {x, y}
 */
export function globalToLocalCoordinates(globalX, globalY, element, elementsMap) {
  const elementPos = getAbsolutePosition(element, elementsMap)
  
  // 考虑元素旋转
  if (element.rotation) {
    // 将坐标转换为相对于元素中心的坐标
    const centerX = elementPos.x + element.width / 2
    const centerY = elementPos.y + element.height / 2
    
    const rotatedX = globalX - centerX
    const rotatedY = globalY - centerY
    
    // 旋转角度（转换为弧度）
    const angle = -element.rotation * Math.PI / 180
    
    // 应用旋转变换
    const cosAngle = Math.cos(angle)
    const sinAngle = Math.sin(angle)
    
    const x = rotatedX * cosAngle - rotatedY * sinAngle + element.width / 2
    const y = rotatedX * sinAngle + rotatedY * cosAngle + element.height / 2
    
    return { x, y }
  }
  
  // 不考虑旋转的情况
  return {
    x: globalX - elementPos.x,
    y: globalY - elementPos.y
  }
}

/**
 * 将相对于元素的本地坐标转换为全局坐标
 * @param {Number} localX 本地X坐标
 * @param {Number} localY 本地Y坐标
 * @param {Object} element 元素
 * @param {Map} elementsMap 元素Map集合
 * @returns {Object} 全局坐标 {x, y}
 */
export function localToGlobalCoordinates(localX, localY, element, elementsMap) {
  const elementPos = getAbsolutePosition(element, elementsMap)
  
  // 考虑元素旋转
  if (element.rotation) {
    // 将坐标转换为相对于元素中心的坐标
    const relativeX = localX - element.width / 2
    const relativeY = localY - element.height / 2
    
    // 旋转角度（转换为弧度）
    const angle = element.rotation * Math.PI / 180
    
    // 应用旋转变换
    const cosAngle = Math.cos(angle)
    const sinAngle = Math.sin(angle)
    
    const rotatedX = relativeX * cosAngle - relativeY * sinAngle
    const rotatedY = relativeX * sinAngle + relativeY * cosAngle
    
    // 转换为全局坐标
    return {
      x: rotatedX + elementPos.x + element.width / 2,
      y: rotatedY + elementPos.y + element.height / 2
    }
  }
  
  // 不考虑旋转的情况
  return {
    x: localX + elementPos.x,
    y: localY + elementPos.y
  }
}