/**
 * 虚拟滚动优化
 * 用于处理大量元素的高效渲染
 */

import { getAbsolutePosition } from './position'

// 扩展缓冲区大小（px）
const BUFFER_SIZE = 200

/**
 * 获取当前视口内的可见元素
 * @param {Map} elementsMap 元素Map集合
 * @param {Object} canvasRef 画布引用
 * @returns {Array} 视口内的可见元素数组
 */
export function getVisibleElements(elementsMap, canvasRef) {
  // 如果元素数量较少，直接返回所有元素
  if (!elementsMap || elementsMap.size < 1000) {
    return Array.from(elementsMap.values())
  }
  
  // 如果没有有效的画布引用，返回空数组
  if (!canvasRef || !canvasRef.$el) {
    return Array.from(elementsMap.values())
  }
  
  // 获取画布的DOM元素和边界
  const canvasEl = canvasRef.$el
  const canvasRect = canvasEl.getBoundingClientRect()
  
  // 获取视口信息
  const viewportLeft = canvasEl.scrollLeft
  const viewportTop = canvasEl.scrollTop
  const viewportRight = viewportLeft + canvasRect.width
  const viewportBottom = viewportTop + canvasRect.height
  
  // 扩展视口范围，提前加载即将进入视口的元素
  const extendedViewportLeft = viewportLeft - BUFFER_SIZE
  const extendedViewportTop = viewportTop - BUFFER_SIZE
  const extendedViewportRight = viewportRight + BUFFER_SIZE
  const extendedViewportBottom = viewportBottom + BUFFER_SIZE
  
  // 过滤出在扩展视口内的元素
  return Array.from(elementsMap.values()).filter(element => {
    // 计算元素的绝对位置（考虑嵌套）
    const absolutePosition = getAbsolutePosition(element, elementsMap)
    
    const elementRight = absolutePosition.x + (element.width || 0)
    const elementBottom = absolutePosition.y + (element.height || 0)
    
    // 检查元素是否在扩展视口内
    return (
      elementRight >= extendedViewportLeft &&
      absolutePosition.x <= extendedViewportRight &&
      elementBottom >= extendedViewportTop &&
      absolutePosition.y <= extendedViewportBottom
    )
  })
}

/**
 * 检查元素是否应该被渲染（用于避免不必要的渲染）
 * @param {Object} element 元素对象
 * @param {Object} viewportInfo 视口信息
 * @param {Map} elementsMap 元素Map集合
 * @returns {Boolean} 如果元素应该被渲染，则返回 true
 */
export function shouldElementRender(element, viewportInfo, elementsMap) {
  // 必须渲染的元素类型
  if (element.alwaysRender) return true
  
  // 计算元素的绝对位置
  const absolutePosition = getAbsolutePosition(element, elementsMap)
  
  const elementRight = absolutePosition.x + (element.width || 0)
  const elementBottom = absolutePosition.y + (element.height || 0)
  
  // 检查元素是否在扩展视口内
  return (
    elementRight >= viewportInfo.left &&
    absolutePosition.x <= viewportInfo.right &&
    elementBottom >= viewportInfo.top &&
    absolutePosition.y <= viewportInfo.bottom
  )
}

/**
 * 优化大量元素的性能
 * @param {Number} totalElements 元素总数
 * @returns {Object} 优化建议
 */
export function getPerformanceOptimizations(totalElements) {
  const optimizations = {
    useVirtualScroll: totalElements > 1000,
    useOcclusionCulling: totalElements > 5000,
    useWebWorkers: totalElements > 10000,
    useLazyLoading: totalElements > 2000,
    useRequestAnimationFrame: true,
    useSimplifiedRendering: totalElements > 7000,
    batchDOMOperations: totalElements > 3000
  }
  
  return optimizations
}