// src/components/DivEditor.vue

<template>
  <div class="editor-container">
    <!-- Element area with template elements -->
    <div class="element-area">
      <div 
        class="template-element" 
        @mousedown="startDragNewElement"
        :style="{ backgroundColor: 'lightblue', width: '100px', height: '50px' }"
      >
        Drag me
      </div>
    </div>

    <!-- Canvas area -->
    <div 
      class="canvas-area" 
      ref="canvasRef"
      @mousedown="onCanvasMouseDown"
      @mousemove="onCanvasMouseMove"
      @mouseup="onCanvasMouseUp"
      @keydown.ctrl="onCtrlKeyDown"
      @keyup.ctrl="onCtrlKeyUp"
      tabindex="0"
    >
      <div 
        v-for="div in divs" 
        :key="div.id" 
        class="canvas-element"
        :class="{ 'selected': selectedDivIds.includes(div.id), 'parent': hasChildren(div.id) }"
        :style="getDivStyle(div)"
        :data-id="div.id"
        :ref="el => { if (el) divRefs[div.id] = el }"
      >
        <div 
          v-if="selectedDivIds.includes(div.id)"
          class="resize-handle top-left" 
          @mousedown.stop="startResize(div.id, 'top-left', $event)"
        ></div>
        <div 
          v-if="selectedDivIds.includes(div.id)"
          class="resize-handle top-right" 
          @mousedown.stop="startResize(div.id, 'top-right', $event)"
        ></div>
        <div 
          v-if="selectedDivIds.includes(div.id)"
          class="resize-handle bottom-left" 
          @mousedown.stop="startResize(div.id, 'bottom-left', $event)"
        ></div>
        <div 
          v-if="selectedDivIds.includes(div.id)"
          class="resize-handle bottom-right" 
          @mousedown.stop="startResize(div.id, 'bottom-right', $event)"
        ></div>
        <div 
          v-if="selectedDivIds.includes(div.id)"
          class="rotation-handle" 
          @mousedown.stop="startRotation(div.id, $event)"
        ></div>
      </div>
    </div>

    <!-- Property panel -->
    <div class="property-panel" v-if="selectedDivIds.length === 1">
      <div class="property-row">
        <label>Width:</label>
        <input type="number" v-model.number="selectedDiv.width" @change="updateProperty('width')">
      </div>
      <div class="property-row">
        <label>Height:</label>
        <input type="number" v-model.number="selectedDiv.height" @change="updateProperty('height')">
      </div>
      <div class="property-row">
        <label>X:</label>
        <input type="number" v-model.number="selectedDiv.x" @change="updateProperty('x')">
      </div>
      <div class="property-row">
        <label>Y:</label>
        <input type="number" v-model.number="selectedDiv.y" @change="updateProperty('y')">
      </div>
      <div class="property-row">
        <label>Rotation:</label>
        <input type="number" v-model.number="selectedDiv.rotation" @change="updateProperty('rotation')">
      </div>
      <div class="property-row">
        <label>Color:</label>
        <input type="color" v-model="selectedDiv.color" @change="updateProperty('color')">
      </div>
      <div class="property-row" v-if="selectedDiv.parentId">
        <label>Parent ID:</label>
        <span>{{ selectedDiv.parentId }}</span>
      </div>
      <button @click="deleteSelectedDivs">Delete</button>
    </div>
  </div>
</template>

<script>
import { ref, computed, reactive, onMounted, onBeforeUnmount } from 'vue';

export default {
  name: 'DivEditor',
  setup() {
    // Canvas reference
    const canvasRef = ref(null);
    
    // State for all divs
    const divs = ref([]);
    const nextId = ref(1);
    const divRefs = reactive({});
    
    // 检查元素是否有子元素
    const hasChildren = (divId) => {
      return divs.value.some(div => div.parentId === divId);
    };
    
    // Selection state
    const selectedDivIds = ref([]);
    
    // Undo/redo state
    const undoStack = ref([]);
    const redoStack = ref([]);
    
    // Dragging state
    const isDragging = ref(false);
    const dragStartX = ref(0);
    const dragStartY = ref(0);
    const draggedDivIds = ref([]);
    const dragStartPositions = ref({});
    const isCtrlPressed = ref(false);
    const dragTarget = ref(null);
    const isNewElementDrag = ref(false);
    
    // Resizing state
    const isResizing = ref(false);
    const resizeDivId = ref(null);
    const resizeHandle = ref(null);
    const resizeStartX = ref(0);
    const resizeStartY = ref(0);
    const resizeStartWidth = ref(0);
    const resizeStartHeight = ref(0);
    
    // Rotation state
    const isRotating = ref(false);
    const rotateDivId = ref(null);
    const rotateStartAngle = ref(0);
    
    // Computed properties
    const selectedDiv = computed(() => {
      if (selectedDivIds.value.length !== 1) return null;
      return divs.value.find(div => div.id === selectedDivIds.value[0]);
    });
    
    // Function to get all ancestor DIVs for a given DIV
    // eslint-disable-next-line no-unused-vars
    const getAncestors = (divId) => {
      const result = [];
      let currentDiv = divs.value.find(div => div.id === divId);
      
      while (currentDiv && currentDiv.parentId) {
        const parent = divs.value.find(div => div.id === currentDiv.parentId);
        if (parent) {
          result.push(parent);
          currentDiv = parent;
        } else {
          break;
        }
      }
      
      return result;
    };
    
    // Function to get all descendant DIVs for a given DIV
    const getDescendants = (divId) => {
      const result = [];
      const directChildren = divs.value.filter(div => div.parentId === divId);
      
      result.push(...directChildren);
      
      for (const child of directChildren) {
        result.push(...getDescendants(child.id));
      }
      
      return result;
    };
    
    // 辅助函数：递归移动所有子元素
    const moveChildrenWithParent = (parentId, deltaX, deltaY) => {
      const childDivs = divs.value.filter(div => div.parentId === parentId);
      
      for (const childDiv of childDivs) {
        if (dragStartPositions.value[childDiv.id]) {
          // 子元素与父元素同步移动
          childDiv.x = dragStartPositions.value[childDiv.id].x + deltaX;
          childDiv.y = dragStartPositions.value[childDiv.id].y + deltaY;
        } else {
          // 如果没有记录起始位置，使用当前位置加上位移
          childDiv.x += deltaX;
          childDiv.y += deltaY;
        }
        
        // 递归移动该子元素的所有子元素
        moveChildrenWithParent(childDiv.id, deltaX, deltaY);
      }
    };
    
    // Save current state to undo stack
    const saveStateForUndo = () => {
      // Clone the current state and push to undo stack
      undoStack.value.push(JSON.parse(JSON.stringify(divs.value)));
      
      // Clear redo stack when a new action is performed
      redoStack.value = [];
    };
    
    // Undo the last action
    const undo = () => {
      if (undoStack.value.length === 0) return;
      
      // Save current state to redo stack
      redoStack.value.push(JSON.parse(JSON.stringify(divs.value)));
      
      // Restore state from undo stack
      divs.value = undoStack.value.pop();
    };
    
    // Redo the last undone action
    const redo = () => {
      if (redoStack.value.length === 0) return;
      
      // Save current state to undo stack
      undoStack.value.push(JSON.parse(JSON.stringify(divs.value)));
      
      // Restore state from redo stack
      divs.value = redoStack.value.pop();
    };
    
    // Start dragging a new element from the element area
    const startDragNewElement = (event) => {
      event.preventDefault();
      
      isNewElementDrag.value = true;
      isDragging.value = true;
      
      // Create a new element at the mouse position
      const canvasRect = canvasRef.value.getBoundingClientRect();
      const x = event.clientX - canvasRect.left;
      const y = event.clientY - canvasRect.top;
      
      // 随机生成一个有效的十六进制颜色
      const randomColor = '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
      
      // Create new div
      const newDiv = {
        id: nextId.value++,
        x,
        y,
        width: 100,
        height: 50,
        rotation: 0,
        color: randomColor,
        parentId: null
      };
      
      saveStateForUndo();
      divs.value.push(newDiv);
      
      // Set as selected and dragged
      selectedDivIds.value = [newDiv.id];
      draggedDivIds.value = [newDiv.id];
      
      // Set drag start coordinates
      dragStartX.value = event.clientX;
      dragStartY.value = event.clientY;
      
      // Remember initial positions
      dragStartPositions.value = {
        [newDiv.id]: { x: newDiv.x, y: newDiv.y }
      };
      
      // Setup global event handlers for dragging
      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);
    };
    
    // Handle mouse down on the canvas
    const onCanvasMouseDown = (event) => {
      // Only handle left mouse button
      if (event.button !== 0) return;
      
      const target = event.target.closest('.canvas-element');
      
      if (target) {
        // 检查是否点击的是调整大小的把手或旋转把手
        if (
          event.target.classList.contains('resize-handle') || 
          event.target.classList.contains('rotation-handle')
        ) {
          // 这些事件在各自的处理函数中处理
          return;
        }
        
        // Clicked on a div
        const divId = parseInt(target.dataset.id);
        dragTarget.value = divId;
        
        // Update selection (respect multi-select with Shift key)
        if (event.shiftKey) {
          if (selectedDivIds.value.includes(divId)) {
            selectedDivIds.value = selectedDivIds.value.filter(id => id !== divId);
          } else {
            selectedDivIds.value.push(divId);
          }
        } else if (!selectedDivIds.value.includes(divId)) {
          selectedDivIds.value = [divId];
        }
        
        // Start dragging the selected divs
        isDragging.value = true;
        draggedDivIds.value = [...selectedDivIds.value];
        
        // Record start position for all dragged divs
        dragStartX.value = event.clientX;
        dragStartY.value = event.clientY;
        dragStartPositions.value = {};
        
        for (const id of draggedDivIds.value) {
          const div = divs.value.find(d => d.id === id);
          if (div) {
            dragStartPositions.value[id] = { x: div.x, y: div.y };
            
            // 同时记录所有子元素的起始位置，以便它们能与父元素同步移动
            const children = getDescendants(id);
            for (const childId of children) {
              const childDiv = divs.value.find(d => d.id === childId);
              if (childDiv) {
                dragStartPositions.value[childId] = { x: childDiv.x, y: childDiv.y };
              }
            }
          }
        }
        
        // 设置全局事件监听器
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
        
        // Prevent default to avoid text selection
        event.preventDefault();
      } else {
        // Clicked on empty canvas area - clear selection
        selectedDivIds.value = [];
      }
    };
    
    // Handle mouse move on the canvas during dragging
    const onCanvasMouseMove = () => {
      // Handle in global handler
    };
    
    // Handle mouse up on the canvas
    const onCanvasMouseUp = () => {
      // Handle in global handler
    };
    
    // Global mouse move handler
    const onMouseMove = (event) => {
      if (!isDragging.value && !isResizing.value && !isRotating.value) return;
      
      if (isDragging.value) {
        // Calculate the movement delta
        const deltaX = event.clientX - dragStartX.value;
        const deltaY = event.clientY - dragStartY.value;
        
        // 首先处理被直接拖动的元素
        for (const id of draggedDivIds.value) {
          const div = divs.value.find(d => d.id === id);
          if (!div) continue;
          
          // Respect parent boundaries unless Ctrl is pressed
          if (div.parentId !== null && !isCtrlPressed.value) {
            const parent = divs.value.find(d => d.id === div.parentId);
            if (!parent) continue;
            
            // Calculate new position
            const newX = dragStartPositions.value[id].x + deltaX;
            const newY = dragStartPositions.value[id].y + deltaY;
            
            // Ensure div stays within parent boundaries
            const parentEl = divRefs[parent.id];
            const divEl = divRefs[div.id];
            
            if (parentEl && divEl) {
              // Calculate bounds (account for rotation later)
              const minX = 0;
              const minY = 0;
              const maxX = parent.width - div.width;
              const maxY = parent.height - div.height;
              
              div.x = Math.max(minX, Math.min(maxX, newX));
              div.y = Math.max(minY, Math.min(maxY, newY));
            }
          } else {
            // Free movement
            div.x = dragStartPositions.value[id].x + deltaX;
            div.y = dragStartPositions.value[id].y + deltaY;
            
            // 如果是父元素在移动，所有子元素必须跟着移动
            moveChildrenWithParent(id, deltaX, deltaY);
          }
        }
      }
      
       else if (isResizing.value) {
        const div = divs.value.find(d => d.id === resizeDivId.value);
        if (!div) return;
        
        const deltaX = event.clientX - resizeStartX.value;
        const deltaY = event.clientY - resizeStartY.value;
        
        // 计算调整大小时的新宽高
        let newWidth = div.width;
        let newHeight = div.height;
        let newX = div.x;
        let newY = div.y;
        
        // Adjust size based on which handle is being dragged
        switch (resizeHandle.value) {
          case 'top-left':
            newWidth = Math.max(10, resizeStartWidth.value - deltaX);
            newHeight = Math.max(10, resizeStartHeight.value - deltaY);
            newX = div.x + (div.width - newWidth);
            newY = div.y + (div.height - newHeight);
            break;
          case 'top-right':
            newWidth = Math.max(10, resizeStartWidth.value + deltaX);
            newHeight = Math.max(10, resizeStartHeight.value - deltaY);
            newY = div.y + (div.height - newHeight);
            break;
          case 'bottom-left':
            newWidth = Math.max(10, resizeStartWidth.value - deltaX);
            newHeight = Math.max(10, resizeStartHeight.value + deltaY);
            newX = div.x + (div.width - newWidth);
            break;
          case 'bottom-right':
            newWidth = Math.max(10, resizeStartWidth.value + deltaX);
            newHeight = Math.max(10, resizeStartHeight.value + deltaY);
            break;
        }
        
        // 应用新的尺寸和位置
        div.width = newWidth;
        div.height = newHeight;
        div.x = newX;
        div.y = newY;
        
        // If the div has a parent, ensure it stays within the parent's boundaries
        if (div.parentId !== null) {
          const parent = divs.value.find(d => d.id === div.parentId);
          if (parent) {
            div.width = Math.min(div.width, parent.width - div.x);
            div.height = Math.min(div.height, parent.height - div.y);
          }
        }
      } else if (isRotating.value) {
        const div = divs.value.find(d => d.id === rotateDivId.value);
        if (!div) return;
        
        // Calculate center of the div
        const divEl = divRefs[div.id];
        if (!divEl) return;
        
        const rect = divEl.getBoundingClientRect();
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        
        // Calculate angle between center and current mouse position
        const angle = Math.atan2(event.clientY - centerY, event.clientX - centerX) * (180 / Math.PI);
        
        // Set the new rotation (add 90 degrees because the rotation handle is on top)
        div.rotation = angle + 90;
      }
    };
    
    // Global mouse up handler
    const onMouseUp = () => {
      if (isDragging.value) {
        // If this was a new element being dragged or an existing element being moved
        if (draggedDivIds.value.length > 0) {
          // 状态保存，用于撤销功能
          if (!isNewElementDrag.value) {
            saveStateForUndo();
          }
          
          // 处理拖动结束时的元素嵌套关系
          for (const id of draggedDivIds.value) {
            const div = divs.value.find(d => d.id === id);
            if (!div) continue;
            
            // 如果按住Ctrl键，则将元素从父元素中分离
            if (isCtrlPressed.value && div.parentId !== null) {
              // 将元素位置从相对坐标转换为绝对坐标
              const divEl = divRefs[div.id];
              if (divEl) {
                const rect = divEl.getBoundingClientRect();
                const canvasRect = canvasRef.value.getBoundingClientRect();
                div.x = rect.left - canvasRect.left;
                div.y = rect.top - canvasRect.top;
                div.parentId = null;
              }
              continue;
            }
            
            // 如果没有按Ctrl键，并且不在拖出父元素，检查当前元素是否应该放入其他元素中
            if (!isCtrlPressed.value && div.parentId === null) {
              // 查找可能的父元素（不包括自己和其后代）
              const potentialParents = divs.value.filter(potentialParent => 
                potentialParent.id !== id && 
                !getDescendants(id).includes(potentialParent)
              );
              
              // 检查是否在某个元素内部
              for (const potentialParent of potentialParents) {
                const parentEl = divRefs[potentialParent.id];
                const divEl = divRefs[div.id];
                
                if (!parentEl || !divEl) continue;
                
                const parentRect = parentEl.getBoundingClientRect();
                const divRect = divEl.getBoundingClientRect();
                
                // 使用元素中心点判断是否在父元素内部
                const divCenterX = divRect.left + divRect.width / 2;
                const divCenterY = divRect.top + divRect.height / 2;
                
                if (
                  divCenterX >= parentRect.left &&
                  divCenterX <= parentRect.right &&
                  divCenterY >= parentRect.top &&
                  divCenterY <= parentRect.bottom
                ) {
                  // 设置父子关系
                  div.parentId = potentialParent.id;
                  
                  // 转换为相对于父元素的坐标
                  div.x = divRect.left - parentRect.left;
                  div.y = divRect.top - parentRect.top;
                  
                  break; // 只设置一个父元素
                }
              }
            }
          }
        }
      } else if (isResizing.value || isRotating.value) {
        // Save state to undo stack after resizing or rotating
        saveStateForUndo();
      }
      
      // 重置所有状态变量
      isDragging.value = false;
      isResizing.value = false;
      isRotating.value = false;
      isNewElementDrag.value = false;
      draggedDivIds.value = [];
      dragTarget.value = null;
      resizeDivId.value = null;
      rotateDivId.value = null;
      
      // 清空起始位置记录
      dragStartX.value = 0;
      dragStartY.value = 0;
      dragStartPositions.value = {};
      resizeStartX.value = 0;
      resizeStartY.value = 0;
      resizeStartWidth.value = 0;
      resizeStartHeight.value = 0;
      rotateStartAngle.value = 0;
      
      // 移除全局事件监听器
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };
    
    // Handle Ctrl key down
    const onCtrlKeyDown = () => {
      isCtrlPressed.value = true;
    };
    
    // Handle Ctrl key up
    const onCtrlKeyUp = () => {
      isCtrlPressed.value = false;
    };
    
    // Start resizing a div
    const startResize = (divId, handle, event) => {
      event.preventDefault();
      event.stopPropagation();
      
      isResizing.value = true;
      resizeDivId.value = divId;
      resizeHandle.value = handle;
      
      const div = divs.value.find(d => d.id === divId);
      if (!div) return;
      
      // 保存当前鼠标位置，不仅仅是div位置
      // eslint-disable-next-line no-unused-vars
      const rect = divRefs[div.id].getBoundingClientRect();
      resizeStartX.value = event.clientX;
      resizeStartY.value = event.clientY;
      resizeStartWidth.value = div.width;
      resizeStartHeight.value = div.height;
      
      // Setup global event handlers
      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);
    };
    
    // Start rotating a div
    const startRotation = (divId, event) => {
      event.preventDefault();
      event.stopPropagation();
      
      isRotating.value = true;
      rotateDivId.value = divId;
      
      const div = divs.value.find(d => d.id === divId);
      if (!div) return;
      
      rotateStartAngle.value = div.rotation;
      
      // Setup global event handlers
      document.addEventListener('mousemove', onMouseMove);
      document.addEventListener('mouseup', onMouseUp);
    };
    
    // Get computed style for a div
    const getDivStyle = (div) => {
      return {
        position: 'absolute',
        left: `${div.x}px`,
        top: `${div.y}px`,
        width: `${div.width}px`,
        height: `${div.height}px`,
        transform: `rotate(${div.rotation}deg)`,
        backgroundColor: div.color || '#cccccc',
        border: '1px solid #888',
        boxSizing: 'border-box',
        overflow: 'visible',
        zIndex: selectedDivIds.value.includes(div.id) ? 100 : 1
      };
    };
    
    // Update a property from the property panel
    const updateProperty = () => {
      if (selectedDivIds.value.length !== 1) return;
      
      const div = divs.value.find(d => d.id === selectedDivIds.value[0]);
      if (!div) return;
      
      // Save state before updating property
      saveStateForUndo();
    };
    
    // Delete the selected divs
    const deleteSelectedDivs = () => {
      if (selectedDivIds.value.length === 0) return;
      
      // Save state before deleting
      saveStateForUndo();
      
      // Get all divs to delete (including descendants)
      const divsToDelete = new Set();
      
      for (const id of selectedDivIds.value) {
        divsToDelete.add(id);
        getDescendants(id).forEach(div => divsToDelete.add(div.id));
      }
      
      // Filter out the divs to delete
      divs.value = divs.value.filter(div => !divsToDelete.has(div.id));
      
      // Clear selection
      selectedDivIds.value = [];
    };
    
    // Set up keyboard shortcuts for undo/redo
    const handleKeyDown = (event) => {
      // Undo: Ctrl+Z
      if (event.ctrlKey && event.key === 'z') {
        event.preventDefault();
        undo();
      }
      
      // Redo: Ctrl+Y
      if (event.ctrlKey && event.key === 'y') {
        event.preventDefault();
        redo();
      }
    };
    
    // Set up event listeners
    onMounted(() => {
      document.addEventListener('keydown', handleKeyDown);
    });
    
    // Clean up event listeners
    onBeforeUnmount(() => {
      document.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    });
    
    return {
      canvasRef,
      divs,
      selectedDivIds,
      selectedDiv,
      divRefs,
      isDragging,
      isResizing,
      isRotating,
      isCtrlPressed,
      dragTarget,
      hasChildren,
      startDragNewElement,
      onCanvasMouseDown,
      onCanvasMouseMove,
      onCanvasMouseUp,
      onCtrlKeyDown,
      onCtrlKeyUp,
      startResize,
      startRotation,
      getDivStyle,
      updateProperty,
      deleteSelectedDivs,
      undo,
      redo
    };
  }
};
</script>

<style scoped>
.editor-container {
  display: flex;
  height: 100vh;
  width: 100%;
}

.element-area {
  width: 200px;
  padding: 10px;
  border-right: 1px solid #ccc;
  overflow-y: auto;
}

.canvas-area {
  flex: 1;
  position: relative;
  overflow: auto;
  background-color: #f5f5f5;
}

.property-panel {
  width: 250px;
  padding: 10px;
  border-left: 1px solid #ccc;
  overflow-y: auto;
}

.template-element {
  cursor: move;
  margin-bottom: 10px;
  padding: 10px;
  text-align: center;
  border: 1px solid #888;
}

.canvas-element {
  position: absolute;
  cursor: move;
  background-color: rgba(255, 255, 255, 0.8);
}

.canvas-element.selected {
  outline: 2px solid blue;
  z-index: 1000 !important;
}

.canvas-element.parent {
  background-color: rgba(240, 240, 255, 0.9);
}

.resize-handle {
  position: absolute;
  width: 10px;
  height: 10px;
  background-color: white;
  border: 1px solid blue;
  z-index: 1001;
}

.top-left {
  top: -5px;
  left: -5px;
  cursor: nwse-resize;
}

.top-right {
  top: -5px;
  right: -5px;
  cursor: nesw-resize;
}

.bottom-left {
  bottom: -5px;
  left: -5px;
  cursor: nesw-resize;
}

.bottom-right {
  bottom: -5px;
  right: -5px;
  cursor: nwse-resize;
}

.rotation-handle {
  position: absolute;
  width: 10px;
  height: 10px;
  background-color: green;
  border-radius: 50%;
  top: -20px;
  left: 50%;
  transform: translateX(-50%);
  cursor: grab;
  z-index: 1001;
}

.property-row {
  margin-bottom: 10px;
  display: flex;
  justify-content: space-between;
}

button {
  margin-top: 10px;
  padding: 5px 10px;
}
</style>