<template>
  <div class="element-panel">
    <h3>元素面板</h3>
    <button @click="addElement">添加新元素</button>
  </div>
</template>

<script>
export default {
  emits: ['add-element'],
  
  setup(props, { emit }) {
    const addElement = () => {
      emit('add-element')
    }
    
    return {
      addElement
    }
  }
}
</script>

<style scoped>
.element-panel {
  width: 200px;
  padding: 10px;
  border-right: 1px solid #ccc;
}
</style>