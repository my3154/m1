<template>
  <div 
    :id="'element-' + element.id"
    class="canvas-element"
    :class="{ 'selected': isSelected }"
    :style="elementStyle"
    @mousedown.stop="handleMouseDown"
    :data-id="element.id"
    :data-parent-id="element.parentId"
  >
    <div class="element-content">{{ element.id }}</div>
    
    <div v-if="isSelected" class="element-controls">
      <div class="resize-handle tl" @mousedown.stop="$emit('resize-start', $event, element, 'tl')"></div>
      <div class="resize-handle tr" @mousedown.stop="$emit('resize-start', $event, element, 'tr')"></div>
      <div class="resize-handle bl" @mousedown.stop="$emit('resize-start', $event, element, 'bl')"></div>
      <div class="resize-handle br" @mousedown.stop="$emit('resize-start', $event, element, 'br')"></div>
      <div class="rotate-handle" @mousedown.stop="$emit('rotate-start', $event, element)"></div>
    </div>
  </div>
</template>

<script>
import { computed } from 'vue'

export default {
  props: {
    element: {
      type: Object,
      required: true
    },
    isSelected: {
      type: Boolean,
      default: false
    }
  },
  
  emits: ['mousedown', 'resize-start', 'rotate-start'],
  
  setup(props, { emit }) {
    // 计算元素样式
    const elementStyle = computed(() => {
      return {
        transform: `translate(${props.element.x}px, ${props.element.y}px) rotate(${props.element.rotation}deg)`,
        width: `${props.element.width}px`,
        height: `${props.element.height}px`,
        backgroundColor: props.element.color,
        position: 'absolute',
        zIndex: props.isSelected ? 1000 : 1
      }
    })
    
    // 处理元素鼠标按下事件
    const handleMouseDown = (event) => {
      emit('mousedown', event, props.element)
    }
    
    return {
      elementStyle,
      handleMouseDown
    }
  }
}
</script>

<style scoped>
.canvas-element {
  box-sizing: border-box;
  border: 1px solid transparent;
  cursor: move;
  user-select: none;
}

.canvas-element:hover {
  border-color: #999;
}

.canvas-element.selected {
  border-color: #00f;
}

.element-content {
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.element-controls {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border: 1px solid #00f;
  pointer-events: none;
}

.resize-handle {
  position: absolute;
  width: 10px;
  height: 10px;
  background-color: #fff;
  border: 1px solid #00f;
  pointer-events: auto;
  cursor: pointer;
}

.tl { top: -5px; left: -5px; cursor: nw-resize; }
.tr { top: -5px; right: -5px; cursor: ne-resize; }
.bl { bottom: -5px; left: -5px; cursor: sw-resize; }
.br { bottom: -5px; right: -5px; cursor: se-resize; }

.rotate-handle {
  position: absolute;
  width: 10px;
  height: 10px;
  background-color: #00f;
  border-radius: 50%;
  top: -20px;
  left: 50%;
  transform: translateX(-50%);
  pointer-events: auto;
  cursor: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="black" stroke-width="2"><path d="M12,4 A8,8 0 1,0 20,12" /><polyline points="20,4 20,12 12,12" /></svg>'), auto;
}
</style>