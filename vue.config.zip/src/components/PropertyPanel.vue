<template>
  <div class="property-panel">
    <h3>属性编辑</h3>
    
    <div class="property-group">
      <label>颜色</label>
      <input type="color" v-model="elementProps.color" @change="updateElement">
    </div>
    
    <div class="property-group">
      <label>宽度</label>
      <input type="number" v-model.number="elementProps.width" @change="updateElement">
    </div>
    
    <div class="property-group">
      <label>高度</label>
      <input type="number" v-model.number="elementProps.height" @change="updateElement">
    </div>
    
    <div class="property-group">
      <label>X坐标</label>
      <input type="number" v-model.number="elementProps.x" @change="updateElement">
    </div>
    
    <div class="property-group">
      <label>Y坐标</label>
      <input type="number" v-model.number="elementProps.y" @change="updateElement">
    </div>
    
    <div class="property-group">
      <label>旋转角度</label>
      <input type="number" v-model.number="elementProps.rotation" @change="updateElement">
    </div>
    
    <button class="remove-button" @click="$emit('remove')">删除</button>
  </div>
</template>

<script>
import { ref, watch } from 'vue'

export default {
  props: {
    element: {
      type: Object,
      required: true
    }
  },
  
  emits: ['update', 'remove'],
  
  setup(props, { emit }) {
    // 使用本地状态来处理属性编辑
    const elementProps = ref({ ...props.element })
    
    // 监听输入元素变化
    watch(
      () => props.element,
      (newVal) => {
        elementProps.value = { ...newVal }
      },
      { deep: true }
    )
    
    // 更新元素
    const updateElement = () => {
      emit('update', { ...elementProps.value })
    }
    
    return {
      elementProps,
      updateElement
    }
  }
}
</script>

<style scoped>
.property-panel {
  width: 250px;
  padding: 10px;
  border-left: 1px solid #ccc;
}

.property-group {
  margin-bottom: 10px;
}

.property-group label {
  display: block;
  margin-bottom: 5px;
}

.property-group input {
  width: 100%;
}

.remove-button {
  margin-top: 20px;
  width: 100%;
  background-color: #f44336;
  color: white;
  border: none;
  padding: 8px;
  cursor: pointer;
}

.remove-button:hover {
  background-color: #d32f2f;
}
</style>