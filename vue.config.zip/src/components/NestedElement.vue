<template>
  <div
    :id="'element-' + element.id"
    class="canvas-element"
    :class="{ 'selected': element.id === selectedElementId }"
    :style="elementStyle"
    @mousedown.stop="handleMouseDown($event, element)"
    :data-id="element.id">
    
    <div class="element-content">{{ element.id }}</div>
    
    <!-- 控制点 (调整大小和旋转) -->
    <div v-if="element.id === selectedElementId" class="element-controls">
      <div class="resize-handle tl" @mousedown.stop="handleResizeStart($event, element, 'tl')"></div>
      <div class="resize-handle tr" @mousedown.stop="handleResizeStart($event, element, 'tr')"></div>
      <div class="resize-handle bl" @mousedown.stop="handleResizeStart($event, element, 'bl')"></div>
      <div class="resize-handle br" @mousedown.stop="handleResizeStart($event, element, 'br')"></div>
      <div class="rotate-handle" @mousedown.stop="handleRotateStart($event, element)"></div>
    </div>
    
    <!-- 递归渲染子元素 -->
    <nested-element
      v-for="childElement in childElements"
      :key="childElement.id"
      :element="childElement"
      :elements-map="elementsMap"
      :selected-element-id="selectedElementId"
      @select="$emit('select', $event)"
      @mousedown="$emit('mousedown', $event, $event.element)"
      @resize-start="$emit('resize-start', $event, $event.element, $event.handle)"
      @rotate-start="$emit('rotate-start', $event, $event.element)"
    />
  </div>
</template>

<script>
import { computed } from 'vue'

export default {
  name: 'NestedElement', // 递归组件需要名称
  
  props: {
    element: {
      type: Object,
      required: true
    },
    elementsMap: {
      type: Map,
      required: true
    },
    selectedElementId: {
      type: String,
      default: null
    }
  },
  
  emits: ['select', 'mousedown', 'resize-start', 'rotate-start'],
  
  setup(props, { emit }) {
    // 子元素
    const childElements = computed(() => {
      return Array.from(props.elementsMap.values())
        .filter(el => el.parentId === props.element.id)
    })
    
    // 元素样式
    const elementStyle = computed(() => {
      return {
        transform: `translate(${props.element.x}px, ${props.element.y}px) rotate(${props.element.rotation || 0}deg)`,
        width: `${props.element.width}px`,
        height: `${props.element.height}px`,
        backgroundColor: props.element.color,
        position: 'absolute'
      }
    })
    
    // 处理元素鼠标按下
    const handleMouseDown = (event, element) => {
      event.stopPropagation()
      emit('select', element.id)
      emit('mousedown', event, element)
    }
    
    // 处理调整大小开始
    const handleResizeStart = (event, element, handle) => {
      event.stopPropagation()
      emit('resize-start', event, element, handle)
    }
    
    // 处理旋转开始
    const handleRotateStart = (event, element) => {
      event.stopPropagation()
      emit('rotate-start', event, element)
    }
    
    return {
      childElements,
      elementStyle,
      handleMouseDown,
      handleResizeStart,
      handleRotateStart
    }
  }
}
</script>

<style scoped>
.canvas-element {
  box-sizing: border-box;
  border: 1px solid transparent;
  cursor: move;
  user-select: none;
  position: absolute;
}

.canvas-element:hover {
  border-color: #999;
}

.canvas-element.selected {
  border-color: #00f;
}

.element-content {
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.element-controls {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border: 1px solid #00f;
  pointer-events: none;
}

.resize-handle {
  position: absolute;
  width: 10px;
  height: 10px;
  background-color: #fff;
  border: 1px solid #00f;
  pointer-events: auto;
  cursor: pointer;
}

.tl { top: -5px; left: -5px; cursor: nw-resize; }
.tr { top: -5px; right: -5px; cursor: ne-resize; }
.bl { bottom: -5px; left: -5px; cursor: sw-resize; }
.br { bottom: -5px; right: -5px; cursor: se-resize; }

.rotate-handle {
  position: absolute;
  width: 10px;
  height: 10px;
  background-color: #00f;
  border-radius: 50%;
  top: -20px;
  left: 50%;
  transform: translateX(-50%);
  pointer-events: auto;
  cursor: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="black" stroke-width="2"><path d="M12,4 A8,8 0 1,0 20,12" /><polyline points="20,4 20,12 12,12" /></svg>'), auto;
}
</style>