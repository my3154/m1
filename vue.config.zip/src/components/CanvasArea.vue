<template>
  <div class="canvas-area" 
    ref="canvasRef"
    @mousedown="handleCanvasMouseDown"
    @mousemove="handleCanvasMouseMove"
    @mouseup="handleCanvasMouseUp"
    @mouseleave="handleCanvasMouseUp"
    tabindex="0">
    
    <div
      v-for="element in elements" 
      :key="element.id"
      :id="'element-' + element.id"
      class="canvas-element"
      :class="{ 'selected': element.id === selectedElementId }"
      :style="getElementStyle(element)"
      @mousedown.stop="handleElementMouseDown($event, element)"
      :data-id="element.id"
      :data-parent-id="element.parentId">
      
      <div class="element-content">{{ element.id }}</div>
      
      <div v-if="element.id === selectedElementId" class="element-controls">
        <div class="resize-handle tl" @mousedown.stop="handleResizeStart($event, element, 'tl')"></div>
        <div class="resize-handle tr" @mousedown.stop="handleResizeStart($event, element, 'tr')"></div>
        <div class="resize-handle bl" @mousedown.stop="handleResizeStart($event, element, 'bl')"></div>
        <div class="resize-handle br" @mousedown.stop="handleResizeStart($event, element, 'br')"></div>
        <div class="rotate-handle" @mousedown.stop="handleRotateStart($event, element)"></div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue'

export default {
  props: {
    elements: {
      type: Array,
      required: true
    },
    selectedElementId: {
      type: String,
      default: null
    }
  },
  
  emits: ['select-element', 'deselect', 'update-element', 'add-history'],
  
  setup(props, { emit }) {
    const canvasRef = ref(null)
    
    // 获取元素样式
    const getElementStyle = (element) => {
      return {
        transform: `translate(${element.x}px, ${element.y}px) rotate(${element.rotation || 0}deg)`,
        width: `${element.width}px`,
        height: `${element.height}px`,
        backgroundColor: element.color,
        position: 'absolute',
        zIndex: element.id === props.selectedElementId ? 1000 : 1
      }
    }
    
    // 拖拽相关状态
    const dragState = ref({
      isDragging: false,
      element: null,
      startX: 0,
      startY: 0,
      originalX: 0,
      originalY: 0,
      ctrlPressed: false
    })
    
    // 调整大小相关状态
    const resizeState = ref({
      isResizing: false,
      element: null,
      handle: null,
      startX: 0,
      startY: 0,
      originalWidth: 0,
      originalHeight: 0,
      originalX: 0,
      originalY: 0
    })
    
    // 旋转相关状态
    const rotateState = ref({
      isRotating: false,
      element: null,
      startAngle: 0,
      centerX: 0,
      centerY: 0,
      originalRotation: 0
    })
    
    // 处理元素鼠标按下事件
    const handleElementMouseDown = (event, element) => {
      event.stopPropagation()
      
      // 设置选中元素
      emit('select-element', element.id)
      
      // 初始化拖拽状态
      dragState.value = {
        isDragging: true,
        element,
        startX: event.clientX,
        startY: event.clientY,
        originalX: element.x,
        originalY: element.y,
        ctrlPressed: event.ctrlKey
      }
    }
    
    // 处理画布鼠标按下事件
    const handleCanvasMouseDown = () => {
      // 点击画布空白区域取消选中
      emit('deselect')
    }
    
    // 处理画布鼠标移动事件
    const handleCanvasMouseMove = (event) => {
      // 处理拖拽
      if (dragState.value.isDragging) {
        const dx = event.clientX - dragState.value.startX
        const dy = event.clientY - dragState.value.startY
        
        const element = dragState.value.element
        const newX = dragState.value.originalX + dx
        const newY = dragState.value.originalY + dy
        
        // 更新元素
        const updatedElement = {
          ...element,
          x: newX,
          y: newY
        }
        
        // 发送更新事件
        emit('update-element', updatedElement)
      }
      
      // 处理调整大小
      if (resizeState.value.isResizing) {
        handleResizeMove(event)
      }
      
      // 处理旋转
      if (rotateState.value.isRotating) {
        handleRotateMove(event)
      }
    }
    
    // 处理画布鼠标抬起事件
    const handleCanvasMouseUp = () => {
      // 如果正在拖拽、调整大小或旋转，添加历史记录
      if (dragState.value.isDragging || resizeState.value.isResizing || rotateState.value.isRotating) {
        dragState.value.isDragging = false
        resizeState.value.isResizing = false
        rotateState.value.isRotating = false
        
        emit('add-history')
      }
    }
    
    // 处理调整大小开始
    const handleResizeStart = (event, element, handle) => {
      event.stopPropagation()
      
      resizeState.value = {
        isResizing: true,
        element,
        handle,
        startX: event.clientX,
        startY: event.clientY,
        originalWidth: element.width,
        originalHeight: element.height,
        originalX: element.x,
        originalY: element.y
      }
    }
    
    // 处理调整大小移动
    const handleResizeMove = (event) => {
      if (!resizeState.value.isResizing) return
      
      const dx = event.clientX - resizeState.value.startX
      const dy = event.clientY - resizeState.value.startY
      
      const state = resizeState.value
      let newWidth = state.originalWidth
      let newHeight = state.originalHeight
      let newX = state.originalX
      let newY = state.originalY
      
      // 根据不同的调整柄处理大小和位置
      switch (state.handle) {
        case 'br': // 右下
          newWidth = Math.max(20, state.originalWidth + dx)
          newHeight = Math.max(20, state.originalHeight + dy)
          break
          
        case 'bl': // 左下
          newWidth = Math.max(20, state.originalWidth - dx)
          newHeight = Math.max(20, state.originalHeight + dy)
          newX = state.originalX + (state.originalWidth - newWidth)
          break
          
        case 'tr': // 右上
          newWidth = Math.max(20, state.originalWidth + dx)
          newHeight = Math.max(20, state.originalHeight - dy)
          newY = state.originalY + (state.originalHeight - newHeight)
          break
          
        case 'tl': // 左上
          newWidth = Math.max(20, state.originalWidth - dx)
          newHeight = Math.max(20, state.originalHeight - dy)
          newX = state.originalX + (state.originalWidth - newWidth)
          newY = state.originalY + (state.originalHeight - newHeight)
          break
      }
      
      // 更新元素
      const updatedElement = {
        ...state.element,
        width: newWidth,
        height: newHeight,
        x: newX,
        y: newY
      }
      
      // 发送更新事件
      emit('update-element', updatedElement)
    }
    
    // 处理旋转开始
    const handleRotateStart = (event, element) => {
      event.stopPropagation()
      
      // 计算元素中心点
      const elementRect = document.getElementById('element-' + element.id).getBoundingClientRect()
      const centerX = elementRect.left + elementRect.width / 2
      const centerY = elementRect.top + elementRect.height / 2
      
      // 计算初始角度
      const startAngle = Math.atan2(
        event.clientY - centerY,
        event.clientX - centerX
      ) * (180 / Math.PI)
      
      rotateState.value = {
        isRotating: true,
        element,
        startAngle,
        centerX,
        centerY,
        originalRotation: element.rotation || 0
      }
    }
    
    // 处理旋转移动
    const handleRotateMove = (event) => {
      if (!rotateState.value.isRotating) return
      
      const state = rotateState.value
      
      // 计算当前角度
      const currentAngle = Math.atan2(
        event.clientY - state.centerY,
        event.clientX - state.centerX
      ) * (180 / Math.PI)
      
      // 计算角度差
      let angleDiff = currentAngle - state.startAngle
      
      // 更新元素旋转角度
      const updatedElement = {
        ...state.element,
        rotation: (state.originalRotation + angleDiff) % 360
      }
      
      // 发送更新事件
      emit('update-element', updatedElement)
    }
    
    return {
      canvasRef,
      getElementStyle,
      handleElementMouseDown,
      handleCanvasMouseDown,
      handleCanvasMouseMove,
      handleCanvasMouseUp,
      handleResizeStart,
      handleRotateStart
    }
  }
}
</script>

<style scoped>
.canvas-area {
  flex: 1;
  position: relative;
  overflow: auto;
  background-color: #f0f0f0;
  min-height: 100%;
}

.canvas-element {
  box-sizing: border-box;
  border: 1px solid transparent;
  cursor: move;
  user-select: none;
}

.canvas-element:hover {
  border-color: #999;
}

.canvas-element.selected {
  border-color: #00f;
}

.element-content {
  width: 100%;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
}

.element-controls {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border: 1px solid #00f;
  pointer-events: none;
}

.resize-handle {
  position: absolute;
  width: 10px;
  height: 10px;
  background-color: #fff;
  border: 1px solid #00f;
  pointer-events: auto;
  cursor: pointer;
}

.tl { top: -5px; left: -5px; cursor: nw-resize; }
.tr { top: -5px; right: -5px; cursor: ne-resize; }
.bl { bottom: -5px; left: -5px; cursor: sw-resize; }
.br { bottom: -5px; right: -5px; cursor: se-resize; }

.rotate-handle {
  position: absolute;
  width: 10px;
  height: 10px;
  background-color: #00f;
  border-radius: 50%;
  top: -20px;
  left: 50%;
  transform: translateX(-50%);
  pointer-events: auto;
  cursor: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="black" stroke-width="2"><path d="M12,4 A8,8 0 1,0 20,12" /><polyline points="20,4 20,12 12,12" /></svg>'), auto;
}
</style>