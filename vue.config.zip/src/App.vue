// src/App.vue

<template>
  <div class="app">
    <div class="toolbar">
      <button @click="undo" :disabled="undoStack.length === 0">
        <span>Undo</span> <small>(Ctrl+Z)</small>
      </button>
      <button @click="redo" :disabled="redoStack.length === 0">
        <span>Redo</span> <small>(Ctrl+Y)</small>
      </button>
      <span class="element-count">Elements: {{ divs.length }}</span>
    </div>
    <DivEditor 
      ref="editorRef"
      v-model:divs="divs"
      @undo="undo"
      @redo="redo"
      @update:divs="onDivsUpdated"
    />
  </div>
</template>

<script>
import { ref, onMounted, onBeforeUnmount } from 'vue';
import DivEditor from './components/DivEditor.vue';
import { useOptimizedHistory } from './components/PerformanceOptimizations';

export default {
  name: 'App',
  components: {
    DivEditor
  },
  setup() {
    const editorRef = ref(null);
    const divs = ref([]);
    const undoStack = ref([]);
    const redoStack = ref([]);
    const { saveChange, undo: historyUndo, redo: historyRedo } = useOptimizedHistory();
    
    // Create a large number of test divs for performance testing
    const createTestDivs = (count) => {
      const newDivs = [];
      const canvasWidth = window.innerWidth - 450; // Approximate canvas width
      const canvasHeight = window.innerHeight - 50; // Approximate canvas height
      
      for (let i = 0; i < count; i++) {
        // Create divs with random positions and sizes
        const size = Math.random() * 100 + 20;
        
        newDivs.push({
          id: i + 1,
          x: Math.random() * (canvasWidth - size),
          y: Math.random() * (canvasHeight - size),
          width: size,
          height: size,
          rotation: Math.random() * 360,
          color: `hsl(${Math.random() * 360}, 70%, 70%)`,
          parentId: null
        });
      }
      
      // Create some nested divs for testing
      for (let i = 0; i < Math.min(count / 10, 100); i++) {
        const parentIndex = Math.floor(Math.random() * newDivs.length);
        const childIndex = Math.floor(Math.random() * newDivs.length);
        
        if (parentIndex !== childIndex && !newDivs[parentIndex].parentId) {
          // Make child div smaller and position it within parent
          const parent = newDivs[parentIndex];
          const child = newDivs[childIndex];
          
          child.width = Math.min(child.width, parent.width * 0.8);
          child.height = Math.min(child.height, parent.height * 0.8);
          
          child.x = (parent.width - child.width) / 2;
          child.y = (parent.height - child.height) / 2;
          child.parentId = parent.id;
        }
      }
      
      divs.value = newDivs;
    };
    
    // Keep track of div state changes for undo/redo
    const onDivsUpdated = (newDivs, oldDivs) => {
      saveChange(oldDivs, newDivs);
    };
    
    // Undo the last action
    const undo = () => {
      if (undoStack.value.length === 0) return;
      
      const oldDivs = [...divs.value];
      divs.value = historyUndo(divs.value);
      
      // Save to redo stack
      redoStack.value.push(oldDivs);
    };
    
    // Redo the last undone action
    const redo = () => {
      if (redoStack.value.length === 0) return;
      
      const oldDivs = [...divs.value];
      divs.value = historyRedo(divs.value);
      
      // Save to undo stack
      undoStack.value.push(oldDivs);
    };
    
    // Set up keyboard shortcuts
    const handleKeyDown = (event) => {
      // Undo: Ctrl+Z
      if (event.ctrlKey && event.key === 'z') {
        event.preventDefault();
        undo();
      }
      
      // Redo: Ctrl+Y
      if (event.ctrlKey && event.key === 'y') {
        event.preventDefault();
        redo();
      }
    };
    
    onMounted(() => {
      document.addEventListener('keydown', handleKeyDown);
      
      // Create test divs if needed
      const urlParams = new URLSearchParams(window.location.search);
      const testCount = parseInt(urlParams.get('count') || '0', 10);
      
      if (testCount > 0) {
        createTestDivs(testCount);
      }
    });
    
    onBeforeUnmount(() => {
      document.removeEventListener('keydown', handleKeyDown);
    });
    
    return {
      editorRef,
      divs,
      undoStack,
      redoStack,
      undo,
      redo,
      onDivsUpdated
    };
  }
};
</script>

<style>
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

body {
  font-family: Arial, sans-serif;
  overflow: hidden;
}

.app {
  display: flex;
  flex-direction: column;
  height: 100vh;
  width: 100vw;
}

.toolbar {
  height: 50px;
  padding: 10px;
  border-bottom: 1px solid #ccc;
  display: flex;
  align-items: center;
  gap: 10px;
}

button {
  padding: 5px 10px;
  background-color: #f3f3f3;
  border: 1px solid #ccc;
  border-radius: 3px;
  cursor: pointer;
}

button:hover {
  background-color: #e6e6e6;
}

button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

button small {
  color: #666;
  font-size: 0.8em;
}

.element-count {
  margin-left: auto;
  color: #666;
}
</style>